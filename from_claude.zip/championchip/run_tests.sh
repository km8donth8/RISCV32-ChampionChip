#!/usr/bin/env bash
# run_tests.sh - compiles and runs every testbench. Usage: ./run_tests.sh
# Requires Icarus Verilog (iverilog + vvp).
set -u
RTL=$(ls rtl/*.v | grep -v tb_DMEM)
python3 tests/asm.py tests/isa_test.s > /dev/null   # regenerate isa_test.hex
pass=0; fail=0
for tb in tb/*.v rtl/tb_DMEM.v; do
  n=$(basename "$tb" .v); printf "%-24s " "$n"
  if iverilog -g2012 -I. -o "/tmp/$n.vvp" $RTL "$tb" 2>/dev/null >/dev/null; then
    timeout 300 vvp "/tmp/$n.vvp" > "/tmp/$n.log" 2>&1
    if [ "$(grep -ciE '\[FAIL\]|FAILED|ERROR\(S\)' "/tmp/$n.log")" -eq 0 ]; then
      echo "PASS"; pass=$((pass+1))
    else
      echo "FAIL  (see /tmp/$n.log)"; fail=$((fail+1))
    fi
  else
    echo "COMPILE ERROR"; fail=$((fail+1))
  fi
done
echo "-----------------------------------"
echo "$pass testbenches passing, $fail failing"
