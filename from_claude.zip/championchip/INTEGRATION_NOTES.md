# Integration notes - top-level wiring, control unit, ISA test

Everything here was simulated with Icarus Verilog. `./run_tests.sh` rebuilds and runs all
17 testbenches; current status is 17 passing, 0 failing.

## New files

| File | What it is |
|---|---|
| `rtl/ControlUnit.v` | Multicycle FSM. 9 states: FETCH, DECODE, EXECUTE, MEM_LOAD, MEM_STORE, BRANCH, WRITEBACK, SYS, HALT. Emits the register enables, the ALU/MULT/CRC select codes and the LSU op_size. |
| `rtl/top.v` | Wires every block together per the datapath drawing: PC, memory address mux, IR/A/B/ALU_out/MDR registers, register file, immediate generator, ALU, multiplier, CRC, branch comparator, write-back mux. |
| `tb/tb_top.v` | Runs `firmware.hex` on the whole CPU and checks x1-x6 and two DMEM words. |
| `tb/tb_top_isa.v` | Runs `tests/isa_test.hex` and checks 40 signature words in DMEM. |
| `tests/isa_test.s` | Assembly test covering every instruction class, incl. the organiser's CRC vectors. |
| `tests/asm.py` | Small RV32I + Zmmul + Xicrc assembler (handles labels, `li`, and the custom CRC encodings the normal assembler doesn't know). |
| `run_tests.sh` | Runs the whole regression. |

## Changes to existing files

1. **`rtl/ProgramCounter.v`: added `PC_write`.** This is the missing PC control signal.
   In a multicycle CPU the PC must hold its value during FETCH/DECODE/EXECUTE and only
   update in the state that ends the instruction, so a write enable is required.
   `tb_ProgramCounter.v` ties it to 1 and still passes.

2. **`rtl/IMEM.v`, `rtl/MemoryUnit.v`, `rtl/top.v`: `FIRMWARE` parameter.** The hex file
   name is now a parameter (default `"firmware.hex"`) so different test programs can be
   run without editing the RTL.

3. **`firmware.hex` word 1 corrected: `deadb137` -> `deadc137`.** `lui x2, 0xDEADB`
   followed by `addi x2, x2, -273` gives 0xDEADAEEF, not 0xDEADBEEF. Because `addi`
   sign-extends a negative immediate, the `lui` has to load 0xDEADC000. The three memory
   testbenches that hardcoded the old word were updated to match.

4. **`tb/tb_CRC.v` and `tb/tb_crc_calc.v`: expected values corrected.** The RTL was right
   and the testbench was wrong. The old expected values (0x6B81 / 0x0A6A / 0xCF45) are for
   a bit-reflected CRC. The organiser specified CRC-16/CCITT-FALSE: poly 0x1021, init
   0xFFFF, no input/output reflection, final XOR 0x0000. The correct values for those
   payloads are 0xC782 / 0x588A / 0xBBA8. Confirmed independently: the block reproduces
   the organiser's `_rvbl2_crc_test` result 0x1E82 for all of crcb, crch and crcw.

## Decisions worth reviewing

- **Select codes follow the Block Guide.** ALU Table 9, MULT Table 10, CRC Table 11.
- **`mult_sel` and `crc_sel` come straight from funct3**, which matches those tables.
- **JALR clears bit 0** of the target, per the RISC-V spec.
- **FENCE and ECALL execute as a no-op** (SYS state, PC+4); **EBREAK halts** the core and
  raises `o_halt`. No CSR registers, as agreed. This is what lets a testbench detect the
  end of a program, which is what the validation firmware will need.
- **Cycles per instruction:** 3 (branch, store), 4 (ALU, LUI, AUIPC, jumps, mult, CRC),
  5 (load).
- The `A`/`B`/`ALU_out`/`MDR` registers live in `top.v`. If they should be separate
  modules for the ChipInventor block diagrams in the report, they can be split out.

## ISA coverage (for report section 2)

| Category | Expected | Implemented | Coverage |
|---|---|---|---|
| Arithmetic and Logic (Register) | 10 | 10 | 100% |
| Arithmetic and Logic (Immediate) | 9 | 9 | 100% |
| Load | 5 | 5 | 100% |
| Store | 3 | 3 | 100% |
| Branch | 6 | 6 | 100% |
| Jump | 2 | 2 | 100% |
| Upper Immediate | 2 | 2 | 100% |
| System / Synchronization | 3 | 3 | 100% (no-op / halt, no CSR) |
| Multiplication | 4 | 4 | 100% |
| CRC | 3 | 3 | 100% |
| **Total** | **47** | **47** | **100%** |

Every row above is exercised by `tb_top_isa` and checked against an expected value.

## Next

- Waveforms for report section 6: the two system testbenches write `tb_top.vcd` and
  `tb_top_isa.vcd`; open with GTKWave.
- OpenLane: IMEM (4 MB) and DMEM (8 kB) as written will not synthesise. Shrink both for
  the synthesis run and keep the full sizes for simulation.
