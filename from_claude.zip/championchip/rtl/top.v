`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// top.v - wires the blocks together following the datapath drawing
//
//   PC --(addr mux)--> MemoryUnit --> IR / MDR
//   IR --> RegisterFile --> A,B regs --> ALU / Multiplier / CRC / BranchComparator
//   IR --> ImmediateGenerator --> ALU (B mux) ; PC --> ALU (A mux)
//   ALU --> ALU_out reg --> memory address / PC target / write-back
//   write-back mux: ALU_out | MDR | MULT | CRC | PC+4  --> RegisterFile
//////////////////////////////////////////////////////////////////////////////////
module top #(
    parameter FIRMWARE = "firmware.hex"
)(
    input  wire clk,
    input  wire rst_n,
    output wire o_halt
);
    // ---- control signals ---------------------------------------------------
    wire        ir_write, ab_write, alu_write, mdr_write, pc_write, pc_sel, reg_write;
    wire [2:0]  wb_sel;
    wire [3:0]  alu_control;
    wire        a_sel, b_sel, mem_addr_sel, mem_read, mem_write;
    wire [2:0]  op_size;
    wire [3:0]  mult_sel;
    wire [1:0]  crc_sel;
    wire [2:0]  branch_sel;
    wire        halt;
    wire [3:0]  state;

    // ---- datapath registers and wires ------------------------------------
    wire [31:0] pc, pc_plus4;
    reg  [31:0] ir, A, B, alu_out, mdr;
    wire [31:0] rs1_data, rs2_data, imm, alu_q, mult_rd, crc_rd, mem_rdata;
    wire        branch_taken;
    reg  [31:0] wb_data;

    wire [31:0] mem_addr  = mem_addr_sel ? alu_out : pc;        // fetch uses PC, load/store use ALU_out
    wire [31:0] pc_target = {alu_out[31:1], 1'b0};              // jalr must clear bit 0; harmless for jal/branch

    // ---- program counter ---------------------------------------------------
    ProgramCounter u_pc (
        .i_ALU_output(pc_target),
        .PC_sel      (pc_sel),
        .PC_write    (pc_write),
        .clk         (clk),
        .rst_n       (rst_n),
        .o_PC_Output (pc),
        .o_PC_Plus_4 (pc_plus4)
    );

    // ---- memory system (LSU + address decoder + IMEM + DMEM) ---------------
    MemoryUnit #(.FIRMWARE(FIRMWARE)) u_mem (
        .clk           (clk),
        .write_enable  (mem_write),
        .read_enable   (mem_read),
        .op_size_o     (op_size),
        .core_data_o   (B),            // store data = rs2
        .core_address_o(mem_addr),
        .core_data_i   (mem_rdata)
    );

    // ---- pipeline-style holding registers (multicycle) ---------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ir <= 32'h0; A <= 32'h0; B <= 32'h0; alu_out <= 32'h0; mdr <= 32'h0;
        end else begin
            if (ir_write)  ir      <= mem_rdata;
            if (ab_write)  begin A <= rs1_data; B <= rs2_data; end
            if (alu_write) alu_out <= alu_q;
            if (mdr_write) mdr     <= mem_rdata;
        end
    end

    // ---- register file, immediate, compute blocks --------------------------
    RegisterFile #(.DATA_MEM_SIZE(8192)) u_regfile (
        .clk          (clk),
        .rst_n        (rst_n),
        .reg_write    (reg_write),
        .reg_rd_data  (wb_data),
        .instruction  (ir),
        .reg_rs_1_data(rs1_data),
        .reg_rs_2_data(rs2_data)
    );

    ImmediateGenerator u_imm (
        .instruction       (ir),
        .extended_immediate(imm)
    );

    ALU u_alu (
        .reg_rs_1   (A),
        .reg_rs_2   (B),
        .pc_output  (pc),
        .immediate  (imm),
        .ALU_control(alu_control),
        .A_sel      (a_sel),
        .B_sel      (b_sel),
        .Q          (alu_q)
    );

    Multiplier u_mult (
        .reg_rs_1(A),
        .reg_rs_2(B),
        .mult_sel(mult_sel),
        .rd      (mult_rd)
    );

    CRC u_crc (
        .reg_rs_1(A),
        .reg_rs_2(B),
        .crc_sel (crc_sel),
        .rd      (crc_rd)
    );

    BranchComparator u_bc (
        .reg_rs_1      (A),
        .reg_rs_2      (B),
        .Branch_Sel    (branch_sel),
        .o_Branch_Taken(branch_taken)
    );

    // ---- write-back mux ----------------------------------------------------
    always @(*) begin
        case (wb_sel)
            3'd0:    wb_data = alu_out;
            3'd1:    wb_data = mdr;
            3'd2:    wb_data = mult_rd;
            3'd3:    wb_data = crc_rd;
            3'd4:    wb_data = pc_plus4;    // jal / jalr link register
            default: wb_data = alu_out;
        endcase
    end

    // ---- control unit ------------------------------------------------------
    ControlUnit u_ctrl (
        .clk         (clk),
        .rst_n       (rst_n),
        .instruction (ir),
        .branch_taken(branch_taken),
        .ir_write    (ir_write),
        .ab_write    (ab_write),
        .alu_write   (alu_write),
        .mdr_write   (mdr_write),
        .pc_write    (pc_write),
        .pc_sel      (pc_sel),
        .reg_write   (reg_write),
        .wb_sel      (wb_sel),
        .alu_control (alu_control),
        .a_sel       (a_sel),
        .b_sel       (b_sel),
        .mem_addr_sel(mem_addr_sel),
        .mem_read    (mem_read),
        .mem_write   (mem_write),
        .op_size     (op_size),
        .mult_sel    (mult_sel),
        .crc_sel     (crc_sel),
        .branch_sel  (branch_sel),
        .halt        (halt),
        .state       (state)
    );

    assign o_halt = halt;
endmodule
