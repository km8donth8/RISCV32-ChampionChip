`timescale 1ns / 1ps
// tb_top.v - runs firmware.hex on the whole CPU and checks the registers / DMEM
module tb_top;
    reg  clk = 1'b0;
    reg  rst_n = 1'b0;
    wire halt;
    integer errors = 0;
    integer cyc;

    top dut (.clk(clk), .rst_n(rst_n), .o_halt(halt));
    always #5 clk = ~clk;   // 100 MHz

    task check_reg(input [4:0] r, input [31:0] expected, input [8*24:1] name);
        begin
            if (dut.u_regfile.regs[r] === expected)
                $display("PASS  x%0d = %h   %0s", r, expected, name);
            else begin
                errors = errors + 1;
                $display("FAIL  x%0d = %h, expected %h   %0s", r, dut.u_regfile.regs[r], expected, name);
            end
        end
    endtask

    task check_dmem(input [31:0] word_addr, input [31:0] expected);
        reg [31:0] got;
        begin
            got = {dut.u_mem.u_dmem.mem_b3[word_addr], dut.u_mem.u_dmem.mem_b2[word_addr],
                   dut.u_mem.u_dmem.mem_b1[word_addr], dut.u_mem.u_dmem.mem_b0[word_addr]};
            if (got === expected) $display("PASS  DMEM[%h] = %h", 32'h10010000 + word_addr*4, got);
            else begin errors = errors + 1; $display("FAIL  DMEM[%h] = %h, expected %h", 32'h10010000 + word_addr*4, got, expected); end
        end
    endtask

    initial begin
        $dumpfile("tb_top.vcd");
        $dumpvars(0, tb_top);
        #23 rst_n = 1'b1;

        // run until halt, or until the PC has stopped moving (jal x0,0 loop), or 2000 cycles
        for (cyc = 0; cyc < 2000 && !halt; cyc = cyc + 1) begin
            @(posedge clk);
            if (cyc > 100 && dut.pc == 32'h00400028) cyc = 2000; // reached the end loop
        end
        #1;
        $display("---- firmware.hex finished, PC = %h ----", dut.pc);

        check_reg(1, 32'h10010000, "lui  x1");
        check_reg(2, 32'hDEADBEEF, "lui+addi x2");
        check_reg(3, 32'hDEADBEEF, "lw   x3 (sw round trip)");
        check_reg(4, 32'h000000EF, "lbu  x4");
        check_reg(5, 32'h00400000, "lui  x5");
        check_reg(6, 32'h0000000A, "lw   x6 from IMEM const");
        check_dmem(0, 32'hDEADBEEF);   // sw
        check_dmem(1, 32'h00EFBEEF);   // sh 0xBEEF at +4, sb 0xEF at +6

        if (errors == 0) $display("==== ALL SYSTEM TESTS PASSED ====");
        else             $display("==== %0d SYSTEM TEST(S) FAILED ====", errors);
        $finish;
    end
endmodule
