`timescale 1ns / 1ps
// tb_top_isa.v - runs tests/isa_test.hex (all instruction classes) and checks the DMEM signature
module tb_top_isa;
    reg  clk = 1'b0;
    reg  rst_n = 1'b0;
    wire halt;
    integer errors = 0, checks = 0, cyc;

    top #(.FIRMWARE("tests/isa_test.hex")) dut (.clk(clk), .rst_n(rst_n), .o_halt(halt));
    always #5 clk = ~clk;

    task check_sig(input [31:0] idx, input [31:0] expected, input [8*40:1] name);
        reg [31:0] got;
        begin
            got = {dut.u_mem.u_dmem.mem_b3[idx], dut.u_mem.u_dmem.mem_b2[idx],
                   dut.u_mem.u_dmem.mem_b1[idx], dut.u_mem.u_dmem.mem_b0[idx]};
            checks = checks + 1;
            if (got === expected) $display("PASS  sig[%0d] = %h   %0s", idx, got, name);
            else begin errors = errors + 1; $display("FAIL  sig[%0d] = %h, expected %h   %0s", idx, got, expected, name); end
        end
    endtask

    initial begin
        $dumpfile("tb_top_isa.vcd");
        $dumpvars(0, tb_top_isa);
        #23 rst_n = 1'b1;
        for (cyc = 0; cyc < 20000 && !halt; cyc = cyc + 1) @(posedge clk);
        #1;
        if (!halt) begin errors = errors + 1; $display("FAIL  CPU did not reach ebreak within %0d cycles (PC=%h)", cyc, dut.pc); end
        else $display("---- ebreak reached after %0d cycles, PC = %h ----", cyc, dut.pc);
        `include "tests/isa_test_expected.vh"
        if (errors == 0) $display("==== ALL %0d ISA SIGNATURE CHECKS PASSED ====", checks);
        else             $display("==== %0d OF %0d ISA SIGNATURE CHECKS FAILED ====", errors, checks);
        $finish;
    end
endmodule
