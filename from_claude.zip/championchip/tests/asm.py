#!/usr/bin/env python3
"""Tiny RV32I + Zmmul + Xicrc assembler for the ChampionChip test programs.
Usage: python3 asm.py isa_test.s   -> writes isa_test.hex and isa_test_expected.vh
Supports labels, li/mv/j/nop/ret pseudo-instructions, and 'SIG n, expr, "name"' lines that
declare the expected signature word n (expr may use label names)."""
import re, sys

REGS = {f"x{i}": i for i in range(32)}
REGS.update({"zero":0,"ra":1,"sp":2,"gp":3,"tp":4,"t0":5,"t1":6,"t2":7,"s0":8,"fp":8,"s1":9,
             "a0":10,"a1":11,"a2":12,"a3":13,"a4":14,"a5":15,"a6":16,"a7":17,
             "s2":18,"s3":19,"s4":20,"s5":21,"s6":22,"s7":23,"s8":24,"s9":25,"s10":26,"s11":27,
             "t3":28,"t4":29,"t5":30,"t6":31})
R = {"add":(0,0),"sub":(0,0x20),"sll":(1,0),"slt":(2,0),"sltu":(3,0),"xor":(4,0),"srl":(5,0),
     "sra":(5,0x20),"or":(6,0),"and":(7,0),
     "mul":(0,1),"mulh":(1,1),"mulhsu":(2,1),"mulhu":(3,1),
     "crcb":(0,0x40),"crch":(1,0x40),"crcw":(2,0x40)}
I_ALU = {"addi":0,"slti":2,"sltiu":3,"xori":4,"ori":6,"andi":7}
I_SH  = {"slli":(1,0),"srli":(5,0),"srai":(5,0x20)}
LOAD  = {"lb":0,"lh":1,"lw":2,"lbu":4,"lhu":5}
STORE = {"sb":0,"sh":1,"sw":2}
BR    = {"beq":0,"bne":1,"blt":4,"bge":5,"bltu":6,"bgeu":7}
BASE  = 0x00400000

def reg(s): return REGS[s.strip()]
def num(s, labels):
    s = s.strip()
    if s in labels: return labels[s]
    return eval(s, {"__builtins__":{}}, dict(labels))
def r_type(f7,rs2,rs1,f3,rd,op=0x33): return (f7<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|op
def i_type(imm,rs1,f3,rd,op): return ((imm&0xFFF)<<20)|(rs1<<15)|(f3<<12)|(rd<<7)|op
def s_type(imm,rs2,rs1,f3): return (((imm>>5)&0x7F)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|((imm&0x1F)<<7)|0x23
def b_type(imm,rs2,rs1,f3):
    return (((imm>>12)&1)<<31)|(((imm>>5)&0x3F)<<25)|(rs2<<20)|(rs1<<15)|(f3<<12)|(((imm>>1)&0xF)<<8)|(((imm>>11)&1)<<7)|0x63
def u_type(imm20,rd,op): return ((imm20&0xFFFFF)<<12)|(rd<<7)|op
def j_type(imm,rd):
    return (((imm>>20)&1)<<31)|(((imm>>1)&0x3FF)<<21)|(((imm>>11)&1)<<20)|(((imm>>12)&0xFF)<<12)|(rd<<7)|0x6F
def li_parts(v):
    v &= 0xFFFFFFFF
    lo = v & 0xFFF
    if lo >= 0x800: lo -= 0x1000
    hi = ((v - lo) >> 12) & 0xFFFFF
    return hi, lo

def expand(op, args):
    """pseudo-instructions -> list of (op,args)"""
    if op == "li":
        rd, v = args[0], args[1]
        try: iv = int(v, 0)
        except ValueError: return [("li", args)]   # label-based li resolved later (2 words)
        if -2048 <= iv < 2048: return [("addi",[rd,"x0",v])]
        hi, lo = li_parts(iv)
        return [("lui",[rd,str(hi)]), ("addi",[rd,rd,str(lo)])]
    if op == "nop": return [("addi",["x0","x0","0"])]
    if op == "mv":  return [("addi",[args[0],args[1],"0"])]
    if op == "j":   return [("jal",["x0",args[0]])]
    if op == "ret": return [("jalr",["x0","ra","0"])]
    return [(op,args)]

def parse(path):
    items = []   # (kind, payload)
    for raw in open(path):
        line = raw.split("#")[0].strip()
        if not line: continue
        if line.upper().startswith("SIG "):
            m = re.match(r'SIG\s+(\d+)\s*,\s*(.+?)\s*,\s*"(.*)"\s*$', line)
            items.append(("sig",(int(m.group(1)), m.group(2), m.group(3))))
            continue
        while ":" in line:
            lab, line = line.split(":",1); items.append(("label",lab.strip())); line=line.strip()
        if not line: continue
        parts = line.replace(",", " ").split()
        op, args = parts[0].lower(), parts[1:]
        # lw t0, 8(x1) -> args [t0, 8, x1]
        if op in LOAD or op in STORE or op == "jalr":
            if len(args) == 2 and "(" in args[1]:
                off, base = args[1].split("("); args = [args[0], off, base.rstrip(")")]
            elif op == "jalr" and len(args) == 3 and args[1] in REGS:
                args = [args[0], args[2], args[1]]   # rd, rs1, imm -> rd, imm, rs1
        for e in expand(op, args): items.append(("inst", e))
    return items

def assemble(path):
    items = parse(path)
    # pass 1: addresses
    labels, pc = {}, BASE
    for kind, p in items:
        if kind == "label": labels[p] = pc
        elif kind == "inst": pc += 8 if p[0] == "li" else 4
    # pass 2: encode
    words, pc = [], BASE
    for kind, p in items:
        if kind != "inst": continue
        op, a = p
        if op == "li":  # label li
            hi, lo = li_parts(num(a[1], labels)); rd = reg(a[0])
            words += [u_type(hi, rd, 0x37), i_type(lo, rd, 0, rd, 0x13)]; pc += 8; continue
        if op in R:
            f3, f7 = R[op]; w = r_type(f7, reg(a[2]), reg(a[1]), f3, reg(a[0]))
        elif op in I_ALU: w = i_type(num(a[2],labels), reg(a[1]), I_ALU[op], reg(a[0]), 0x13)
        elif op in I_SH:
            f3, f7 = I_SH[op]; w = i_type((f7<<5)|(num(a[2],labels)&0x1F), reg(a[1]), f3, reg(a[0]), 0x13)
        elif op in LOAD:  w = i_type(num(a[1],labels), reg(a[2]), LOAD[op], reg(a[0]), 0x03)
        elif op in STORE: w = s_type(num(a[1],labels), reg(a[0]), reg(a[2]), STORE[op])
        elif op in BR:    w = b_type(num(a[2],labels) - pc, reg(a[1]), reg(a[0]), BR[op])
        elif op == "jal": w = j_type(num(a[1],labels) - pc, reg(a[0]))
        elif op == "jalr": w = i_type(num(a[1],labels), reg(a[2]), 0, reg(a[0]), 0x67)
        elif op == "lui":  w = u_type(num(a[1],labels), reg(a[0]), 0x37)
        elif op == "auipc":w = u_type(num(a[1],labels), reg(a[0]), 0x17)
        elif op == "fence": w = 0x0000000F
        elif op == "ecall": w = 0x00000073
        elif op == "ebreak": w = 0x00100073
        else: raise SystemExit(f"unknown instruction {op}")
        words.append(w & 0xFFFFFFFF); pc += 4
    sigs = [(n, num(e, labels) & 0xFFFFFFFF, name) for kind,(n,e,name) in
            [(k,p) for k,p in items if k == "sig"]]
    return words, sigs, labels

if __name__ == "__main__":
    src = sys.argv[1]; stem = src.rsplit(".",1)[0]
    words, sigs, labels = assemble(src)
    with open(stem + ".hex", "w") as f:
        f.write("// generated by asm.py from %s - %d instructions, load at 0x00400000\n@00000000\n" % (src, len(words)))
        for w in words: f.write("%08x\n" % w)
    with open(stem + "_expected.vh", "w") as f:
        f.write("// generated by asm.py - expected signature words (DMEM word index, value, name)\n")
        for n, v, name in sigs: f.write("check_sig(%d, 32'h%08x, \"%s\");\n" % (n, v, name))
    print("assembled %d instructions, %d signature checks" % (len(words), len(sigs)))
