# isa_test.s - exercises every instruction class of RV32I_Zmmul_Xicrc.
# Each result is stored ("signature") into DMEM word n at 0x10010000 + 4n;
# tb_top_isa.v compares those words with the SIG lines below.
_start:
    li    x1, 0x10010000        # DMEM base = signature base
    addi  x2, x0, 5             # a = 5
    addi  x3, x0, -3            # b = -3
# ---- register-register ALU (10) ----
    add   t0, x2, x3
    sw    t0, 0(x1)
    sub   t0, x2, x3
    sw    t0, 4(x1)
    and   t0, x2, x3
    sw    t0, 8(x1)
    or    t0, x2, x3
    sw    t0, 12(x1)
    xor   t0, x2, x3
    sw    t0, 16(x1)
    sll   t0, x2, x2
    sw    t0, 20(x1)
    srl   t0, x3, x2
    sw    t0, 24(x1)
    sra   t0, x3, x2
    sw    t0, 28(x1)
    slt   t0, x3, x2
    sw    t0, 32(x1)
    sltu  t0, x3, x2
    sw    t0, 36(x1)
# ---- immediate ALU (9) ----
    addi  t0, x3, 10
    sw    t0, 40(x1)
    slti  t0, x2, 6
    sw    t0, 44(x1)
    sltiu t0, x2, 4
    sw    t0, 48(x1)
    xori  t0, x2, 15
    sw    t0, 52(x1)
    ori   t0, x2, 8
    sw    t0, 56(x1)
    andi  t0, x2, 4
    sw    t0, 60(x1)
    slli  t0, x2, 4
    sw    t0, 64(x1)
    srli  t0, x3, 28
    sw    t0, 68(x1)
    srai  t0, x3, 28
    sw    t0, 72(x1)
# ---- upper immediate (2) ----
    lui   t0, 0x12345
    sw    t0, 76(x1)
L_auipc:
    auipc t0, 0
    sw    t0, 80(x1)
# ---- multiplication (4) ----
    mul    t0, x3, x2
    sw     t0, 84(x1)
    mulh   t0, x3, x2
    sw     t0, 88(x1)
    mulhsu t0, x3, x2
    sw     t0, 92(x1)
    mulhu  t0, x3, x2
    sw     t0, 96(x1)
# ---- loads (5) and stores (3), scratch area at +0x200 ----
    sw    x3, 0x200(x1)
    lw    t0, 0x200(x1)
    sw    t0, 100(x1)
    lh    t0, 0x200(x1)
    sw    t0, 104(x1)
    lhu   t0, 0x202(x1)
    sw    t0, 108(x1)
    lb    t0, 0x200(x1)
    sw    t0, 112(x1)
    lbu   t0, 0x203(x1)
    sw    t0, 116(x1)
    sw    x0, 0x204(x1)
    sb    x2, 0x205(x1)
    li    t1, 0xA0
    sh    t1, 0x206(x1)
    lw    t0, 0x204(x1)
    sw    t0, 120(x1)
# ---- branches (6): t2 counts only the correct path ----
    addi  t2, x0, 0
    beq   x0, x0, B1            # taken
    addi  t2, t2, 100
B1: addi  t2, t2, 1
    bne   x0, x0, B2            # not taken
    addi  t2, t2, 1
B2: blt   x3, x2, B3            # -3 < 5 taken
    addi  t2, t2, 100
B3: addi  t2, t2, 1
    bge   x3, x2, B4            # not taken
    addi  t2, t2, 1
B4: bltu  x3, x2, B5            # 0xFFFFFFFD < 5 unsigned: not taken
    addi  t2, t2, 1
B5: bgeu  x3, x2, B6            # taken
    addi  t2, t2, 100
B6: addi  t2, t2, 1
    addi  t3, x0, 3
LOOP:
    addi  t2, t2, 1             # backward branch loop, 3 times
    addi  t3, t3, -1
    bne   t3, x0, LOOP
    sw    t2, 124(x1)
# ---- jumps (2) ----
JAL_PC:
    jal   t4, J1
    addi  t2, t2, 100
J1: sw    t4, 128(x1)
JALR_PC:
    auipc t5, 0
    jalr  t6, t5, 16            # forward over two instructions
    addi  t2, t2, 100
    addi  t2, t2, 100
J2: sw    t6, 132(x1)
    auipc t5, 0
    jalr  t6, t5, 13            # odd target: bit 0 must be cleared
    addi  t2, t2, 100
J3: sw    t2, 136(x1)
# ---- CRC (3): the organiser's _rvbl2_crc_test, expected 0x1E82 ----
    li    a7, 0x1E82
    li    s0, 0xFFFF
    li    s1, 0x12
    li    s2, 0x34
    li    s3, 0x56
    li    s4, 0x78
    li    s5, 0x90
    li    s6, 0xAB
    li    s7, 0xCD
    li    s8, 0xEF
    crcb  s0, s1, s0
    crcb  s0, s2, s0
    crcb  s0, s3, s0
    crcb  s0, s4, s0
    crcb  s0, s5, s0
    crcb  s0, s6, s0
    crcb  s0, s7, s0
    crcb  s0, s8, s0
    sw    s0, 140(x1)
    li    t0, 0xFFFF
    li    t1, 0x1234
    li    t2, 0x5678
    li    t3, 0x90AB
    li    t4, 0xCDEF
    crch  t0, t1, t0
    crch  t0, t2, t0
    crch  t0, t3, t0
    crch  t0, t4, t0
    sw    t0, 144(x1)
    li    a0, 0xFFFF
    li    a1, 0x12345678
    li    a2, 0x90ABCDEF
    crcw  a0, a1, a0
    crcw  a0, a2, a0
    sw    a0, 148(x1)
    bne   s0, a7, _error
    bne   t0, a7, _error
    bne   a0, a7, _error
# ---- system / synchronization (3) ----
    addi  t0, x0, 1
    fence
    ecall
    addi  t0, t0, 1
    sw    t0, 152(x1)
    li    t0, 0x600D
    sw    t0, 156(x1)
    ebreak                      # halt: end of test
_error:
    li    t0, 0xBAD
    sw    t0, 156(x1)
    ebreak

SIG 0,  2,          "add   5 + -3"
SIG 1,  8,          "sub   5 - -3"
SIG 2,  5,          "and"
SIG 3,  0xFFFFFFFD, "or"
SIG 4,  0xFFFFFFF8, "xor"
SIG 5,  0xA0,       "sll   5 << 5"
SIG 6,  0x07FFFFFF, "srl   -3 >> 5"
SIG 7,  0xFFFFFFFF, "sra   -3 >>> 5"
SIG 8,  1,          "slt   -3 < 5"
SIG 9,  0,          "sltu  0xFFFFFFFD < 5"
SIG 10, 7,          "addi  -3 + 10"
SIG 11, 1,          "slti  5 < 6"
SIG 12, 0,          "sltiu 5 < 4"
SIG 13, 10,         "xori  5 ^ 15"
SIG 14, 13,         "ori   5 | 8"
SIG 15, 4,          "andi  5 & 4"
SIG 16, 80,         "slli  5 << 4"
SIG 17, 0xF,        "srli  -3 >> 28"
SIG 18, 0xFFFFFFFF, "srai  -3 >>> 28"
SIG 19, 0x12345000, "lui"
SIG 20, L_auipc,    "auipc = its own address"
SIG 21, 0xFFFFFFF1, "mul   -3 * 5"
SIG 22, 0xFFFFFFFF, "mulh"
SIG 23, 0xFFFFFFFF, "mulhsu"
SIG 24, 4,          "mulhu 0xFFFFFFFD * 5 high"
SIG 25, 0xFFFFFFFD, "lw"
SIG 26, 0xFFFFFFFD, "lh    sign extend"
SIG 27, 0x0000FFFF, "lhu"
SIG 28, 0xFFFFFFFD, "lb    sign extend"
SIG 29, 0x000000FF, "lbu"
SIG 30, 0x00A00500, "sb + sh byte lanes"
SIG 31, 9,          "beq/bne/blt/bge/bltu/bgeu + loop"
SIG 32, JAL_PC + 4, "jal   link = pc+4"
SIG 33, JALR_PC + 8,"jalr  link = pc+4"
SIG 34, 9,          "jalr  odd target bit 0 cleared"
SIG 35, 0x1E82,     "crcb  x8 (organiser test)"
SIG 36, 0x1E82,     "crch  x4 (organiser test)"
SIG 37, 0x1E82,     "crcw  x2 (organiser test)"
SIG 38, 2,          "fence + ecall executed as no-op"
SIG 39, 0x600D,     "reached end without _error"
