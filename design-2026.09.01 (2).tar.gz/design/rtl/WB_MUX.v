module WB_MUX (
    input  wire [31:0] alu_out,
    input  wire [31:0] mdr,
    input  wire [31:0] pc_plus4,
    input  wire [1:0]  wb_sel,

    output reg  [31:0] wb_data
);

always @(*) begin
    case (wb_sel)
        2'b00: wb_data = alu_out;
        2'b01: wb_data = mdr;
        2'b10: wb_data = pc_plus4;
        default: wb_data = 32'h00000000;
    endcase
end

endmodule