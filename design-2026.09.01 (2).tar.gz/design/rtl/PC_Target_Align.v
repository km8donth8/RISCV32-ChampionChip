module PC_Target_Align (
    input  wire [31:0] alu_out,
    input  wire        pc_lsb_clear,

    output wire [31:0] pc_target
);

assign pc_target = pc_lsb_clear
                 ? {alu_out[31:1], 1'b0}
                 : alu_out;

endmodule